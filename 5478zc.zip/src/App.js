import UsersData from "./Components/UsersData";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <UsersData/>
    </div>
  );
}
