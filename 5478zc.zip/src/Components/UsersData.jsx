
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import "./Table.css"


 const UsersData = () => {
    const [data,setData]=useState([])  
    const[search,setSearch]=useState("")
    const[dataCopy,setDataCopy]=useState([]) 
    
    const getData=async()=>{
        const apiData=await axios.get("https://jsonplaceholder.typicode.com/users")
        console.log( "APIDATA",apiData.data)
        setData(apiData.data)
      console.log("data",data)
      setDataCopy(apiData.data)
    }
    useEffect(()=>{
        getData()
     },[])

     useEffect(()=>{
       const result= dataCopy.filter((item)=>item.name.toLowerCase().includes(search.toUpperCase())
       )

       setData(result)
     },[search])

    const handleDelete=(ind)=>{
     console.log(ind)
     const result=data.filter((item,i)=>i!=ind)
     setData(result)
     }

    return (
        <div className="a" >
              <h1>This is Table Component</h1> 
             <input type="text" onChange={(e)=>setSearch(e.target.value)}/>

              <button onClick={getData}>ShowData</button>
              <table>
                          <tr>
                            <th>SR no</th>
                              <th>NAME</th>
                              <th>USERNAME</th>
                              <th>CITY</th>
                              <th>EMAIL</th>  
                              <th>Delete</th>                         
                              <th>LANGUAGE</th>
                          </tr>
                          {data.map((item,ind)=>{
                              return(
                                  <tr>
                                      <td className="b" >{ind+1}</td>
                                      <td>{item.name}</td>
                                      <td>{item.username}</td>
                                      <td>{item.address.city}</td>
                                      <td>{item.email}</td>
                                      
                                      <td>{item.language}</td>
                                      
                                <td> <button onClick={()=>handleDelete(ind)}>DELETE</button> </td>
                                  </tr>
                              )
  
                          })}
                      </table>
          </div>
      );
  };


  
  export default UsersData;
